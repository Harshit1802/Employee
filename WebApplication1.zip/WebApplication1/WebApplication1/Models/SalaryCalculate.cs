﻿namespace WebApplication1.Models
{
    public class SalaryCalculate
    {
        public int emp_id { get; set; }
        public string workType { get; set; }

        public int hourlyWorked { get; set; }

        public int weeksWorked { get; set; }
    }
}
