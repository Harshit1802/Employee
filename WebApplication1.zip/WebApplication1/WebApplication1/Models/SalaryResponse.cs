﻿namespace WebApplication1.Models
{
    public class SalaryResponse
    {
        public int emp_id { get; set; }
        public  string name { get; set; }
        public int calculatedSalary { get; set; }

        public string workType { get; set; }
    }
}
