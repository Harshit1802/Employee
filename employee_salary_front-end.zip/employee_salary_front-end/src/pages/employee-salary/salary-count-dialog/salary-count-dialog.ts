import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';

@Component({
  selector: 'app-salary-count-dialog',
  imports: [MatDialogModule,MatInputModule,MatButtonModule,MatInputModule,ReactiveFormsModule],
  templateUrl: './salary-count-dialog.html',
  styleUrl: './salary-count-dialog.scss'
})
export class SalaryCountDialog {
  readonly dialogRef = inject(MatDialogRef<SalaryCountDialog>);
  readonly data = inject<any>(MAT_DIALOG_DATA);
 exampleForm: FormGroup;
 calculateSalary : number = 0;
  constructor(private fb: FormBuilder) {
    this.exampleForm = this.fb.group({
      emp_id : [''],
      weeksWorked: [0, Validators.required],
      hoursWorked: [0, Validators.required],
      workType: [''],
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  calc():void{

  }
}
