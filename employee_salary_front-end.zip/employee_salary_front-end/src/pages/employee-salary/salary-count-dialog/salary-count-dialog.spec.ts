import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalaryCountDialog } from './salary-count-dialog';

describe('SalaryCountDialog', () => {
  let component: SalaryCountDialog;
  let fixture: ComponentFixture<SalaryCountDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SalaryCountDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SalaryCountDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
