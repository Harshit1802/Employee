import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeSalaryList } from '../pages/employee-salary/employee-salary-list/employee-salary-list';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,EmployeeSalaryList],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  protected title = 'employee_salary_front-end';
}
