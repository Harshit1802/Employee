﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32.SafeHandles;
using WebApplication1.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        // GET: api/<EmployeesController>
        private readonly DataContext _context;

        public EmployeesController(DataContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            var result =  _context.Employee.ToList();
            return result;
        }

        // GET api/<EmployeesController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<EmployeesController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Employee value)
        {
             _context.Employee.Add(value);
             _context.SaveChanges();
            return Ok();
        }

        [HttpPost("salaryCalc")]
        public IActionResult SalaryCalculate([FromBody] SalaryCalculate value)
        {
        
           var emp =  _context.Employee.Where(x=> x.id == value.emp_id).FirstOrDefault();
            var calculateSalary = new SalaryResponse();
            if (emp != null)
            {
                var oneDaySalary = emp.baseSalary / 30;
                var weekDaySalary = oneDaySalary * 7;
                var hourlySalary = oneDaySalary / 24;
                 calculateSalary = new SalaryResponse
                {
                    emp_id = emp.id,
                    name = emp.name,
                    calculatedSalary = weekDaySalary + hourlySalary,
                    workType = emp.workType,


                };

            }
            return Ok(calculateSalary);

        }
        // PUT api/<EmployeesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<EmployeesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }

    public interface IActionResult<T>
    {
    }
}
