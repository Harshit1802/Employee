import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
   
  constructor(private http: HttpClient) {
  }
  static apiUrl = 'http://localhost:5288/api/Employees';
  getEmployee():Observable<any> {
    return this.http.get(EmployeeService.apiUrl);
  }
}
