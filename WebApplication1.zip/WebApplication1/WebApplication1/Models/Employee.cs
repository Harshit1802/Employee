﻿namespace WebApplication1.Models
{
    public class Employee
    {

        public int id { get; set; }
        public required string name { get; set; }
        public string workType { get; set; }

        public int baseSalary { get; set; }

    }
}
