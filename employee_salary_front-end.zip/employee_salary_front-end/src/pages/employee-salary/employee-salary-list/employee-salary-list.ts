import { Component, inject, OnInit } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { EmployeeService } from '../../../services/employee.service';
import { MatButton, MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { SalaryCountDialog } from '../salary-count-dialog/salary-count-dialog';
import { MatIconModule } from '@angular/material/icon';


export interface Employees {
  name: string;
  empId: number;
  workeType: number;
  salary: string;
}

@Component({
  selector: 'app-employee-salary-list',
  imports: [MatTableModule,MatButtonModule,MatIconModule],
  templateUrl: './employee-salary-list.html',
  styleUrl: './employee-salary-list.scss'
})


export class EmployeeSalaryList implements OnInit{
  constructor(private empService:EmployeeService){}
    readonly dialog = inject(MatDialog);
 displayedColumns: string[] = ['id', 'name', 'workType', 'salary','action'];
 dataSource = new MatTableDataSource<Employees>();
 ngOnInit(): void {
  this.empService.getEmployee().subscribe(x=>{
    this.dataSource.data = x;
  })
 }

 openDialog(value:any): void {
    const dialogRef = this.dialog.open(SalaryCountDialog, {
      data: value,
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      if (result !== undefined) {
      }
    });
  }
}
